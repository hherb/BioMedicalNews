"""Agent base class for LLM-powered tasks."""

from bmlib.agents.base import BaseAgent

__all__ = ["BaseAgent"]
