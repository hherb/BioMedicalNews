"""bmlib — shared library for biomedical literature tools."""

__version__ = "0.1.0"
